"""
CLI entry point: run a full valuation for a single asset defined in a YAML config file.

Usage
-----
    bve-asset --config examples/configs/relay_rly2608.yaml --memo bd --charts
    bve-asset --config examples/configs/xyz101.yaml --memo hf --charts --all-memos
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bve.config.assumptions_loader import AssumptionsLoader as _AssumptionsLoader
from bve.entities.asset import DevelopmentStage as _DevelopmentStage
from bve.entities.asset import Modality as _Modality
from bve.entities.asset import TherapeuticArea as _TherapeuticArea
from bve.entities.trial import EndpointType as _EndpointType
from bve.models.pos_model import (
    BiomarkerSelectionStrength as _BiomarkerSelectionStrength,
    CMCRiskLevel as _CMCRiskLevel,
    CompetitiveBenchmarkPosition as _CompetitiveBenchmarkPosition,
    CompetitivePressure as _CompetitivePressure,
    DataMaturityLevel as _DataMaturityLevel,
    MoAPrecedent as _MoAPrecedent,
    PriorPhaseDataStrength as _PriorPhaseDataStrength,
    RegulatoryApprovalBar as _RegulatoryApprovalBar,
    SafetyProfile as _SafetyProfile,
    SampleSizeAdequacy as _SampleSizeAdequacy,
)
from bve.models.trial_design_features import (
    ComparatorFit as _ComparatorFit,
    EvidenceDesignQuality as _EvidenceDesignQuality,
    RegulatoryPathwayRisk as _RegulatoryPathwayRisk,
)

# Resolved once at import — avoids re-loading YAML on every CLI invocation
_COMMERCIAL_DEFAULTS = _AssumptionsLoader.get().commercial_defaults
_MC_DEFAULTS = _AssumptionsLoader.get()


_VALID_THERAPEUTIC_AREAS = {ta.value for ta in _TherapeuticArea}
_VALID_STAGES = {s.value for s in _DevelopmentStage}
_VALID_MODALITIES = {m.value for m in _Modality}
_VALID_ENDPOINT_TYPES = {e.value for e in _EndpointType}
_VALID_MOA_PRECEDENT = {m.value for m in _MoAPrecedent}
_VALID_SAMPLE_ADEQUACY = {s.value for s in _SampleSizeAdequacy}
_VALID_SAFETY = {s.value for s in _SafetyProfile}
_VALID_COMPETITION = {c.value for c in _CompetitivePressure}
_VALID_RAB = {r.value for r in _RegulatoryApprovalBar}
_VALID_BIOMARKER_SELECTION = {b.value for b in _BiomarkerSelectionStrength}
_VALID_PRIOR_PHASE = {p.value for p in _PriorPhaseDataStrength}
_VALID_DATA_MATURITY = {d.value for d in _DataMaturityLevel}
_VALID_CMC_RISK = {c.value for c in _CMCRiskLevel}
_VALID_COMP_BENCHMARK = {c.value for c in _CompetitiveBenchmarkPosition}
_VALID_EVIDENCE_DESIGN_QUALITY = {e.value for e in _EvidenceDesignQuality}
_VALID_COMPARATOR_FIT = {c.value for c in _ComparatorFit}
_VALID_REGULATORY_PATHWAY_RISK = {r.value for r in _RegulatoryPathwayRisk}

_SAMPLE_SIZE_ADEQUACY_ALIASES = {
    "large": "well_powered",
}


def _normalize_sample_size_adequacy(value: str) -> str:
    """Normalize legacy sample-size labels to current enum values."""
    return _SAMPLE_SIZE_ADEQUACY_ALIASES.get(value, value)


def _validate_config(cfg: dict, path: Path) -> None:
    """
    Validate required fields and enum values in a YAML config.
    Raises SystemExit with a clear message on the first error found.
    """
    errors = []

    def _check(condition: bool, msg: str) -> None:
        if not condition:
            errors.append(msg)

    a = cfg.get("asset", {})
    _check(bool(a.get("id")), "asset.id is required")
    _check(bool(a.get("name")), "asset.name is required")
    _check(bool(a.get("indication")), "asset.indication is required")
    _check(
        a.get("therapeutic_area") in _VALID_THERAPEUTIC_AREAS,
        f"asset.therapeutic_area must be one of {sorted(_VALID_THERAPEUTIC_AREAS)}, got: {a.get('therapeutic_area')!r}"
    )
    _check(
        a.get("stage") in _VALID_STAGES,
        f"asset.stage must be one of {sorted(_VALID_STAGES)}, got: {a.get('stage')!r}"
    )
    if a.get("modality"):
        _check(
            a["modality"] in _VALID_MODALITIES,
            f"asset.modality must be one of {sorted(_VALID_MODALITIES)}, got: {a['modality']!r}"
        )

    c = cfg.get("company", {})
    _check(bool(c.get("id")), "company.id is required")
    _check(bool(c.get("name")), "company.name is required")
    _check(c.get("cash_millions") is not None, "company.cash_millions is required")
    _check(c.get("shares_outstanding_millions") is not None, "company.shares_outstanding_millions is required")
    if c.get("shares_outstanding_millions") is not None:
        _check(float(c["shares_outstanding_millions"]) > 0, "company.shares_outstanding_millions must be > 0")

    trials = cfg.get("trials", [])
    _check(len(trials) > 0, "at least one trial is required under 'trials:'")
    for i, t in enumerate(trials):
        prefix = f"trials[{i}]"
        _check(t.get("phase") in _VALID_STAGES, f"{prefix}.phase must be one of {sorted(_VALID_STAGES)}, got: {t.get('phase')!r}")
        _check(t.get("duration_years") is not None, f"{prefix}.duration_years is required")
        _check(t.get("cost_millions") is not None, f"{prefix}.cost_millions is required")
        _check(t.get("success_probability") is not None, f"{prefix}.success_probability is required")
        sp = t.get("success_probability")
        if sp is not None:
            _check(0 < float(sp) < 1, f"{prefix}.success_probability must be between 0 and 1, got: {sp}")
        if t.get("endpoint_type"):
            _check(
                t["endpoint_type"] in _VALID_ENDPOINT_TYPES,
                f"{prefix}.endpoint_type must be one of {sorted(_VALID_ENDPOINT_TYPES)}, got: {t['endpoint_type']!r}"
            )

    m = cfg.get("market_model", {})
    has_lots = bool(m.get("lines_of_therapy"))
    if not has_lots:
        _check(
            m.get("total_addressable_market_millions") is not None or m.get("addressable_patients_annual") is not None,
            "market_model requires either total_addressable_market_millions, addressable_patients_annual, "
            "or lines_of_therapy (multi-line of therapy segments)"
        )
        _check(m.get("peak_penetration") is not None, "market_model.peak_penetration is required (or use lines_of_therapy)")
        pp = m.get("peak_penetration")
        if pp is not None:
            _check(0 < float(pp) <= 1, f"market_model.peak_penetration must be between 0 and 1, got: {pp}")

    pos = cfg.get("pos_adjusters", {})
    if pos.get("apply_pos_model"):
        for phase_key in ("phase_1", "phase_2", "phase_3", "nda_bla"):
            pc = pos.get(phase_key)
            if pc is None:
                continue
            prefix = f"pos_adjusters.{phase_key}"
            if pc.get("moa_precedent"):
                _check(pc["moa_precedent"] in _VALID_MOA_PRECEDENT,
                       f"{prefix}.moa_precedent must be one of {sorted(_VALID_MOA_PRECEDENT)}, got: {pc['moa_precedent']!r}")
            if pc.get("sample_size_adequacy"):
                sample_size_value = _normalize_sample_size_adequacy(
                    str(pc["sample_size_adequacy"])
                )
                _check(sample_size_value in _VALID_SAMPLE_ADEQUACY,
                       f"{prefix}.sample_size_adequacy must be one of "
                       f"{sorted(_VALID_SAMPLE_ADEQUACY)}"
                       f" (legacy aliases: {sorted(_SAMPLE_SIZE_ADEQUACY_ALIASES)}), "
                       f"got: {pc['sample_size_adequacy']!r}")
            if pc.get("safety_profile"):
                _check(pc["safety_profile"] in _VALID_SAFETY,
                       f"{prefix}.safety_profile must be one of {sorted(_VALID_SAFETY)}, got: {pc['safety_profile']!r}")
            if pc.get("competitive_pressure"):
                _check(pc["competitive_pressure"] in _VALID_COMPETITION,
                       f"{prefix}.competitive_pressure must be one of {sorted(_VALID_COMPETITION)}, got: {pc['competitive_pressure']!r}")
            if pc.get("regulatory_approval_bar"):
                _check(pc["regulatory_approval_bar"] in _VALID_RAB,
                       f"{prefix}.regulatory_approval_bar must be one of {sorted(_VALID_RAB)}, got: {pc['regulatory_approval_bar']!r}")
            if pc.get("biomarker_selection"):
                _check(pc["biomarker_selection"] in _VALID_BIOMARKER_SELECTION,
                       f"{prefix}.biomarker_selection must be one of {sorted(_VALID_BIOMARKER_SELECTION)}, got: {pc['biomarker_selection']!r}")
            if pc.get("prior_phase_data"):
                _check(pc["prior_phase_data"] in _VALID_PRIOR_PHASE,
                       f"{prefix}.prior_phase_data must be one of {sorted(_VALID_PRIOR_PHASE)}, got: {pc['prior_phase_data']!r}")
            if pc.get("data_maturity"):
                _check(pc["data_maturity"] in _VALID_DATA_MATURITY,
                       f"{prefix}.data_maturity must be one of {sorted(_VALID_DATA_MATURITY)}, got: {pc['data_maturity']!r}")
            if pc.get("cmc_risk"):
                _check(pc["cmc_risk"] in _VALID_CMC_RISK,
                       f"{prefix}.cmc_risk must be one of {sorted(_VALID_CMC_RISK)}, got: {pc['cmc_risk']!r}")
            if pc.get("competitive_benchmark"):
                _check(pc["competitive_benchmark"] in _VALID_COMP_BENCHMARK,
                       f"{prefix}.competitive_benchmark must be one of {sorted(_VALID_COMP_BENCHMARK)}, got: {pc['competitive_benchmark']!r}")

    td = cfg.get("trial_design", {})
    if td.get("apply_design_model"):
        for phase_key in ("phase_1", "phase_2", "phase_3", "nda_bla"):
            pc = td.get(phase_key)
            if pc is None:
                continue
            prefix = f"trial_design.{phase_key}"
            if pc.get("evidence_design_quality"):
                _check(pc["evidence_design_quality"] in _VALID_EVIDENCE_DESIGN_QUALITY,
                       f"{prefix}.evidence_design_quality must be one of {sorted(_VALID_EVIDENCE_DESIGN_QUALITY)}, got: {pc['evidence_design_quality']!r}")
            if pc.get("comparator_fit"):
                _check(pc["comparator_fit"] in _VALID_COMPARATOR_FIT,
                       f"{prefix}.comparator_fit must be one of {sorted(_VALID_COMPARATOR_FIT)}, got: {pc['comparator_fit']!r}")
            if pc.get("regulatory_pathway_risk"):
                _check(pc["regulatory_pathway_risk"] in _VALID_REGULATORY_PATHWAY_RISK,
                       f"{prefix}.regulatory_pathway_risk must be one of {sorted(_VALID_REGULATORY_PATHWAY_RISK)}, got: {pc['regulatory_pathway_risk']!r}")

    if errors:
        print(f"\nERROR: Config validation failed — {path}", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        sys.exit(1)


def _load_config(path: Path) -> dict:
    # Merge analyst confidential overrides (examples/configs/overrides/<TICKER>.yaml)
    # when present. The `private:` section is intentionally dropped here so it never
    # reaches the engine objects or outputs; only `confidential_overrides` are merged.
    from bve.pipeline.config_resolver import load_resolved_config

    cfg, _provenance = load_resolved_config(path)
    return cfg


def _build_objects(cfg: dict):
    """Parse config dict → Asset, Company, trials, MarketModel."""
    # Auto-generated configs can include metadata that should not affect parsing.
    cfg = dict(cfg)
    cfg.pop("_meta", None)

    from bve.entities.asset import Asset, DevelopmentStage, TherapeuticArea, Modality, Catalyst
    from bve.entities.company import Company
    from bve.entities.trial import ClinicalTrial, TrialPhase, EndpointType
    from bve.models.market_model import MarketModel

    a = cfg["asset"]
    asset = Asset(
        id=a["id"],
        name=a["name"],
        indication=a["indication"],
        therapeutic_area=TherapeuticArea(a["therapeutic_area"]),
        stage=DevelopmentStage(a["stage"]),
        modality=Modality(a.get("modality", "small_molecule")),
        mechanism_of_action=a.get("mechanism_of_action"),
        biological_target=a.get("biological_target"),
        discount_rate=a.get("discount_rate", float(_COMMERCIAL_DEFAULTS["discount_rate"])),
        royalty_rate=a.get("royalty_rate", 0.0),
        upcoming_catalysts=[Catalyst(**c) for c in a.get("upcoming_catalysts", [])],
        competitor_assets=a.get("competitor_assets", []),
        differentiation_notes=a.get("differentiation_notes"),
        notes=a.get("notes"),
    )

    c = cfg["company"]
    company = Company(
        id=c["id"],
        name=c["name"],
        ticker=c.get("ticker"),
        cash_millions=c["cash_millions"],
        debt_millions=c.get("debt_millions", 0.0),
        shares_outstanding_millions=c["shares_outstanding_millions"],
        burn_rate_millions_per_quarter=c.get("burn_rate_millions_per_quarter"),
        current_price=c.get("current_price"),
        asset_ids=[asset.id],
        notes=c.get("notes"),
    )

    trials = []
    for t in cfg.get("trials", []):
        trials.append(ClinicalTrial(
            asset_id=asset.id,
            phase=TrialPhase(t["phase"]),
            nct_id=t.get("nct_id"),
            success_probability=t["success_probability"],
            duration_years=t["duration_years"],
            cost_millions=t["cost_millions"],
            enrollment=t.get("enrollment"),
            primary_endpoint=t.get("primary_endpoint"),
            endpoint_type=EndpointType(t.get("endpoint_type", "surrogate_validated")),
            notes=t.get("notes"),
        ))

    m = cfg["market_model"]
    from bve.models.market_model import LineOfTherapySegment, LifecycleEvent
    from bve.models.competition_model import (
        CompetitionModel, CompetitorLaunch, CrowdingModel, FirstMoverConfig, ClassSaturationProfile
    )
    lot_cfgs = m.get("lines_of_therapy", [])
    lots = [LineOfTherapySegment(**seg) for seg in lot_cfgs] if lot_cfgs else []

    # Support competition_model nested in market_model (new) or top-level competition list (legacy)
    competition = None
    comp_section = m.get("competition_model") or {}
    comp_cfgs_nested = comp_section.get("competitors", [])
    comp_cfgs_legacy = cfg.get("competition", [])
    raw_comp_cfgs = comp_cfgs_nested or comp_cfgs_legacy
    if raw_comp_cfgs:
        competitors = [CompetitorLaunch(**c) for c in raw_comp_cfgs]
        cm_kwargs: dict = {"competitors": competitors}
        crowding_cfg = comp_section.get("crowding_model")
        if crowding_cfg:
            cm_kwargs["crowding_model"] = CrowdingModel(**crowding_cfg)
        fm_cfg = comp_section.get("first_mover_config")
        if fm_cfg:
            cm_kwargs["first_mover_config"] = FirstMoverConfig(**fm_cfg)
        sat_cfg = comp_section.get("saturation_profile")
        if sat_cfg:
            cm_kwargs["saturation_profile"] = ClassSaturationProfile(**sat_cfg)
        competition = CompetitionModel(**cm_kwargs)

    # Lifecycle events nested in market_model
    lc_cfgs = m.get("lifecycle_events", [])
    lifecycle_events = [LifecycleEvent(**e) for e in lc_cfgs] if lc_cfgs else []

    # Mode 4: commercial_inputs (patient × price × share decomposition)
    commercial_inputs = None
    ci_cfg = m.get("commercial_inputs")
    if ci_cfg:
        from bve.models.commercial_inputs import CommercialInputs, PatientPool, PricingModel, ShareModel
        pp_cfg = ci_cfg["patient_pool"]
        pr_cfg = ci_cfg["pricing"]
        sh_cfg = ci_cfg["share"]
        patient_pool = PatientPool(**pp_cfg)
        # Support both from_wac() path and direct net_price_usd path
        if "wac_per_year_usd" in pr_cfg and "gross_to_net_rate" in pr_cfg and "net_price_usd" not in pr_cfg:
            pricing = PricingModel.from_wac(
                wac_per_year_usd=pr_cfg["wac_per_year_usd"],
                gross_to_net_rate=pr_cfg["gross_to_net_rate"],
                launch_discount=pr_cfg.get("launch_discount", 0.10),
                annual_erosion_rate=pr_cfg.get("annual_erosion_rate", 0.02),
                uncertainty_cv=pr_cfg.get("uncertainty_cv", 0.15),
            )
        else:
            pricing = PricingModel(**pr_cfg)
        share = ShareModel(**sh_cfg)
        commercial_inputs = CommercialInputs(
            patient_pool=patient_pool,
            pricing=pricing,
            share=share,
            ex_us_revenue_multiple=ci_cfg.get("ex_us_revenue_multiple", 1.0),
        )

    market_model = MarketModel(
        asset_id=asset.id,
        lines_of_therapy=lots,
        competition_model=competition,
        lifecycle_events=lifecycle_events,
        commercial_inputs=commercial_inputs,
        total_addressable_market_millions=m.get("total_addressable_market_millions"),
        addressable_patients_annual=m.get("addressable_patients_annual"),
        net_price_per_patient_usd=m.get("net_price_per_patient_usd"),
        peak_penetration=m.get("peak_penetration", float(_COMMERCIAL_DEFAULTS["peak_penetration"])),
        years_to_peak=m.get("years_to_peak", 5),
        patent_life_years=m.get("patent_life_years", 12),
        cogs_rate=m.get("cogs_rate", float(_COMMERCIAL_DEFAULTS["cogs_rate"])),
        sgna_rate_launch=m.get("sgna_rate_launch", 0.40),
        sgna_rate_mature=m.get("sgna_rate_mature", 0.20),
    )

    return asset, company, trials, market_model


def _build_pos_adjusters(cfg: dict):
    """Parse optional pos_adjusters section from config.

    Supports both legacy field names (competitive_pressure, biomarker_selected_population,
    strong_prior_phase_data) and new field names (regulatory_approval_bar, biomarker_selection,
    prior_phase_data, data_maturity, cmc_risk, competitive_benchmark). New fields take
    precedence when both are present.
    """
    from bve.entities.trial import TrialPhase
    from bve.models.pos_model import (
        BiomarkerSelectionStrength,
        CMCRiskLevel,
        CompetitiveBenchmarkPosition,
        CompetitivePressure,
        DataMaturityLevel,
        MoAPrecedent,
        POSAdjusters,
        PriorPhaseDataStrength,
        RegulatoryApprovalBar,
        SafetyProfile,
        SampleSizeAdequacy,
    )
    from bve.entities.trial import EndpointType

    pos_cfg = cfg.get("pos_adjusters", {})
    if not pos_cfg.get("apply_pos_model", False):
        return None, False

    phase_map = {
        "phase_1": TrialPhase.PHASE_1,
        "phase_2": TrialPhase.PHASE_2,
        "phase_3": TrialPhase.PHASE_3,
        "nda_bla": TrialPhase.NDA_BLA,
    }

    adjusters = {}
    for phase_key, phase_enum in phase_map.items():
        phase_cfg = pos_cfg.get(phase_key)
        if phase_cfg is None:
            continue

        kwargs: dict = dict(
            endpoint_type=EndpointType(phase_cfg.get("endpoint_type", "surrogate_validated")),
            moa_precedent=MoAPrecedent(phase_cfg.get("moa_precedent", "partial")),
            sample_size_adequacy=SampleSizeAdequacy(
                _normalize_sample_size_adequacy(
                    phase_cfg.get("sample_size_adequacy", "adequate")
                )
            ),
            safety_profile=SafetyProfile(phase_cfg.get("safety_profile", "minor")),
            has_breakthrough_designation=phase_cfg.get("has_breakthrough_designation", False),
        )

        # New field names take precedence over legacy fields
        if phase_cfg.get("regulatory_approval_bar"):
            kwargs["regulatory_approval_bar"] = RegulatoryApprovalBar(phase_cfg["regulatory_approval_bar"])
        elif phase_cfg.get("competitive_pressure"):
            kwargs["competitive_pressure"] = CompetitivePressure(phase_cfg["competitive_pressure"])

        if phase_cfg.get("biomarker_selection"):
            kwargs["biomarker_selection"] = BiomarkerSelectionStrength(phase_cfg["biomarker_selection"])
        elif phase_cfg.get("biomarker_selected_population"):
            kwargs["biomarker_selected_population"] = phase_cfg["biomarker_selected_population"]

        if phase_cfg.get("prior_phase_data"):
            kwargs["prior_phase_data"] = PriorPhaseDataStrength(phase_cfg["prior_phase_data"])
        elif phase_cfg.get("strong_prior_phase_data"):
            kwargs["strong_prior_phase_data"] = phase_cfg["strong_prior_phase_data"]

        if phase_cfg.get("data_maturity"):
            kwargs["data_maturity"] = DataMaturityLevel(phase_cfg["data_maturity"])

        if phase_cfg.get("cmc_risk"):
            kwargs["cmc_risk"] = CMCRiskLevel(phase_cfg["cmc_risk"])

        if phase_cfg.get("competitive_benchmark"):
            kwargs["competitive_benchmark"] = CompetitiveBenchmarkPosition(phase_cfg["competitive_benchmark"])

        adjusters[phase_enum] = POSAdjusters(**kwargs)

    return adjusters, True


def _build_design_adjusters(cfg: dict):
    """Parse optional trial_design section from config.

    Returns (design_adjusters_dict, apply_design_model_bool).
    design_adjusters_dict maps TrialPhase → TrialDesignFeatureSet.
    """
    from bve.entities.trial import TrialPhase
    from bve.models.trial_design_features import (
        ComparatorFit, EvidenceDesignQuality, RegulatoryPathwayRisk, TrialDesignFeatureSet
    )

    td_cfg = cfg.get("trial_design", {})
    if not td_cfg.get("apply_design_model", False):
        return None, False

    phase_map = {
        "phase_1": TrialPhase.PHASE_1,
        "phase_2": TrialPhase.PHASE_2,
        "phase_3": TrialPhase.PHASE_3,
        "nda_bla": TrialPhase.NDA_BLA,
    }

    adjusters = {}
    for phase_key, phase_enum in phase_map.items():
        phase_cfg = td_cfg.get(phase_key)
        if phase_cfg is None:
            continue
        adjusters[phase_enum] = TrialDesignFeatureSet(
            evidence_design_quality=EvidenceDesignQuality(
                phase_cfg.get("evidence_design_quality", "rct_double_blind")
            ),
            comparator_fit=ComparatorFit(
                phase_cfg.get("comparator_fit", "acceptable_not_ideal")
            ),
            regulatory_pathway_risk=RegulatoryPathwayRisk(
                phase_cfg.get("regulatory_pathway_risk", "standard")
            ),
        )

    return adjusters, True


def _build_strategic_takeout(cfg: dict):
    """Parse the optional ``strategic_takeout`` section from config.

    Opt-in: returns a ``StrategicTakeoutPremium`` only when the block is present and
    ``enabled: true``. Returns ``None`` otherwise — the layer stays disabled (no-op),
    leaving rNPV/revenue/cost/scenarios/Monte Carlo untouched.

    YAML schema (all premium keys optional; default 30/50/80 band)::

        strategic_takeout:
          enabled: true
          low_premium_pct: 0.30
          base_premium_pct: 0.50
          high_premium_pct: 0.80
    """
    st_cfg = cfg.get("strategic_takeout")
    if not st_cfg or not st_cfg.get("enabled", False):
        return None

    from bve.models.strategic_takeout import (
        DEFAULT_BASE_PREMIUM_PCT,
        DEFAULT_HIGH_PREMIUM_PCT,
        DEFAULT_LOW_PREMIUM_PCT,
        StrategicTakeoutPremium,
    )

    kwargs: dict = dict(
        low_premium_pct=st_cfg.get("low_premium_pct", DEFAULT_LOW_PREMIUM_PCT),
        base_premium_pct=st_cfg.get("base_premium_pct", DEFAULT_BASE_PREMIUM_PCT),
        high_premium_pct=st_cfg.get("high_premium_pct", DEFAULT_HIGH_PREMIUM_PCT),
    )
    if st_cfg.get("rationale"):
        kwargs["rationale"] = tuple(st_cfg["rationale"])
    return StrategicTakeoutPremium(**kwargs)


def _output_dir(cfg: dict, base: str) -> Path:
    """Derive output directory: outputs/<ticker_or_asset_name>/"""
    ticker = cfg.get("company", {}).get("ticker") or cfg.get("asset", {}).get("id", "asset")
    return Path(base) / ticker.upper()


def _load_selected_buyer_problem(path: str | None, problem_id: str | None):
    if not path:
        return None
    from bve.intelligence.buyer_problem_library import BuyerProblemLibrary

    try:
        library = BuyerProblemLibrary.from_yaml(path)
    except Exception as exc:
        print(f"ERROR: Failed to load buyer problem config: {exc}", file=sys.stderr)
        sys.exit(2)
    problems = library.problems
    if not problems:
        print("ERROR: Buyer problem config contains no problems", file=sys.stderr)
        sys.exit(2)
    if problem_id is None:
        if len(problems) > 1:
            print("ERROR: --buyer-problem-id required when config has multiple problems", file=sys.stderr)
            sys.exit(2)
        return problems[0]
    for problem in problems:
        if getattr(problem, "problem_id", None) == problem_id:
            return problem
    print(f"ERROR: buyer problem id not found: {problem_id}", file=sys.stderr)
    sys.exit(2)


def main():
    parser = argparse.ArgumentParser(description="BVE: Run single-asset valuation")
    parser.add_argument("--config", required=True, help="Path to asset YAML config")
    parser.add_argument("--memo", choices=["bd", "vc", "hf"], default="bd")
    parser.add_argument("--all-memos", action="store_true", help="Generate all three memo types")
    parser.add_argument("--charts", action="store_true", help="Save charts")
    parser.add_argument("--out", default="outputs", help="Base output directory (default: outputs/)")
    parser.add_argument("--n-sims", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--science-thesis", action="store_true", help="Build and render Layer 0 Science Thesis without changing POS by default")
    parser.add_argument("--apply-science-pos-modifier", action="store_true", help="Apply Science Thesis heuristic modifier to technical POS; requires --science-thesis")
    parser.add_argument("--buyer-problem", help="Path to buyer problem YAML config; requires --science-thesis")
    parser.add_argument("--buyer-problem-id", help="Problem ID to select from buyer problem config")
    args = parser.parse_args()

    if args.apply_science_pos_modifier and not args.science_thesis:
        print("ERROR: --apply-science-pos-modifier requires --science-thesis", file=sys.stderr)
        sys.exit(2)
    if args.buyer_problem and not args.science_thesis:
        print("ERROR: --buyer-problem requires --science-thesis", file=sys.stderr)
        sys.exit(2)
    if args.buyer_problem_id and not args.buyer_problem:
        print("ERROR: --buyer-problem-id requires --buyer-problem", file=sys.stderr)
        sys.exit(2)

    cfg_path = Path(args.config)
    if not cfg_path.exists():
        print(f"ERROR: Config file not found: {cfg_path}", file=sys.stderr)
        sys.exit(1)

    cfg = _load_config(cfg_path)
    _validate_config(cfg, cfg_path)
    asset, company, trials, market_model = _build_objects(cfg)
    pos_adjusters, apply_pos = _build_pos_adjusters(cfg)
    design_adjusters, apply_design = _build_design_adjusters(cfg)

    from bve.models.monte_carlo import MonteCarloParams, PhaseSuccessDistribution
    from bve.entities.trial import TrialPhase
    from bve.valuation.valuation_engine import ValuationEngine

    # Build MC params — allow per-phase distributions from config
    mc_cfg = cfg.get("monte_carlo", {})
    phase_dists = []
    for phase_key, mean_key in [("phase_1", None), ("phase_2", None), ("phase_3", None), ("nda_bla", None)]:
        pd_cfg = mc_cfg.get("phase_distributions", {}).get(phase_key)
        if pd_cfg:
            phase_dists.append(PhaseSuccessDistribution(
                phase=TrialPhase(phase_key),
                mean=pd_cfg["mean"],
                equivalent_sample_size=pd_cfg.get("ess", 20),
            ))

    mc_params = MonteCarloParams(
        n_simulations=args.n_sims,
        random_seed=mc_cfg.get("random_seed", args.seed),
        peak_sales_cv=mc_cfg.get("peak_sales_cv", _MC_DEFAULTS.mc_peak_sales_cv),
        discount_rate_std=mc_cfg.get("discount_rate_std", _MC_DEFAULTS.mc_discount_rate_std),
        years_to_peak_std=mc_cfg.get("years_to_peak_std", _MC_DEFAULTS.mc_years_to_peak_std),
        phase_distributions=phase_dists,
        use_default_correlations=mc_cfg.get("use_default_correlations", True),
    )

    buyer_problem = _load_selected_buyer_problem(args.buyer_problem, args.buyer_problem_id)

    engine = ValuationEngine(
        asset, company, trials, market_model,
        pos_adjusters=pos_adjusters,
        design_adjusters=design_adjusters,
        mc_params=mc_params,
        apply_pos_model=apply_pos,
        apply_design_model=apply_design,
        analyst_notes=cfg.get("analyst_notes"),
        config_path=str(cfg_path.resolve()),
        limitations=cfg.get("limitations"),
        thesis_changers=cfg.get("thesis_changers"),
        enable_science_thesis=args.science_thesis,
        apply_science_pos_modifier=args.apply_science_pos_modifier,
        buyer_problem=buyer_problem,
        buyer_problem_id=args.buyer_problem_id,
    )

    # Optional: assumption source overrides and decision framing
    engine.sources = cfg.get("sources")
    decision_framing_cfg = cfg.get("decision_framing")
    if decision_framing_cfg:
        from bve.valuation.assumptions import DecisionFraming, DownsideDriver, VariantPerception
        vp_cfg = decision_framing_cfg.get("variant_perception")
        vp = VariantPerception(**vp_cfg) if vp_cfg else None
        dd_list = [DownsideDriver(**d) for d in decision_framing_cfg.get("downside_drivers", [])]
        engine.decision_framing = DecisionFraming(
            variant_perception=vp,
            kill_criteria=decision_framing_cfg.get("kill_criteria", []),
            downside_drivers=dd_list,
        )

    print(f"\nRunning valuation: {asset.name} ({company.ticker or company.name})")
    print(f"  Config:       {cfg_path}")
    print(f"  POS model:    {'enabled' if apply_pos else 'using YAML point estimates'}")
    if apply_design:
        phase_summaries = []
        for ph, feat in (design_adjusters or {}).items():
            phase_summaries.append(f"{ph.value}: {feat.evidence_design.value}/{feat.approval_pathway.value}")
        print(f"  Design model: enabled ({'; '.join(phase_summaries)})")
    print(f"  MC sims:      {args.n_sims:,}")
    if market_model.competition_model and market_model.competition_model.competitors:
        print(f"  Competition:  {market_model.competition_model.summary()}")
    output = engine.run()

    # Apply optional strategic takeout premium (control-premium-over-rNPV layer; opt-in).
    _st_premium = _build_strategic_takeout(cfg)
    if _st_premium is not None:
        output = output.model_copy(update={"strategic_takeout_premium": _st_premium})

    # --- Console summary ---
    d = output.summary_dict
    print(f"\n{'═'*58}")
    print(f"  {asset.name} | {asset.indication}")
    print(f"  {company.name} ({company.ticker or '—'})")
    print(f"{'═'*58}")
    print(f"  {'rNPV':<34} ${d['rnpv_millions']:>10,.1f}M")
    print(f"  {'P(Approval)':<34} {d['prob_approval_pct']:>11}")
    print(f"  {'Peak Sales (base)':<34} ${d['peak_sales_millions']:>10,.0f}M")
    print(f"  {'Years to Launch':<34} {d['years_to_launch']:>11.1f} yrs")
    print(f"  {'Net Cash':<34} ${d['net_cash_millions']:>10,.0f}M")
    print(f"  {'NAV/Share':<34} ${d['nav_per_share']:>10.2f}")
    if d["current_price"]:
        print(f"  {'Current Price':<34} ${d['current_price']:>10.2f}")
        upside = d["implied_upside_pct"]
        direction = "upside" if upside and upside > 0 else "downside"
        print(f"  {'Implied vs NAV':<34} {abs(upside or 0):>10.0f}% {direction}")
    print(f"{'─'*58}")
    print(f"  {'MC Mean':<34} ${d['mc_mean']:>10,.0f}M")
    print(f"  {'MC P10 – P90':<34}   ${d['mc_p10']:>7,.0f}M – ${d['mc_p90']:,.0f}M")
    print(f"  {'Scenarios Bull / Base / Bear':<34}   "
          f"${d['bull_rnpv']:,.0f} / ${d['base_rnpv']:,.0f} / ${d['bear_rnpv']:,.0f}M")
    # Investment verdict (BD side requires the M&A scan — see bve-report).
    from bve.analysis.dual_track import build_dual_track
    _iv = build_dual_track(output).investment
    if _iv.assessed:
        print(f"{'─'*58}")
        print(f"  {'Investment view':<34} {_iv.stance.upper()} ({_iv.valuation_label})")
        _read = {
            "market_expectation_too_low": "market expectation too low",
            "market_expectation_too_high": "market expectation too high",
        }.get(_iv.market_expectation_read)
        if _read:
            print(f"  {'Market read':<34} {_read:>11}")
    print(f"{'═'*58}")

    # --- Save outputs ---
    out_dir = _output_dir(cfg, args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    artifacts: dict[str, str] = {}

    # JSON
    json_path = output.save_json(out_dir / "valuation.json")
    artifacts["valuation.json"] = str(json_path)

    # Memos
    memo_types = ["bd", "vc", "hf"] if args.all_memos else [args.memo]
    for mt in memo_types:
        from bve.reporting.memo_generator import generate_memo
        from bve.reporting.export import markdown_to_docx
        md = generate_memo(output, memo_type=mt)
        md_path = out_dir / f"{mt}_memo.md"
        md_path.write_text(md, encoding="utf-8")
        artifacts[f"{mt}_memo.md"] = str(md_path)
        try:
            docx_path = out_dir / f"{mt}_memo.docx"
            markdown_to_docx(md, docx_path, title=f"{asset.name} — {mt.upper()} Memo")
            artifacts[f"{mt}_memo.docx"] = str(docx_path)
        except Exception as e:
            artifacts[f"{mt}_memo.docx"] = f"ERROR: {e}"

    # Charts
    if args.charts:
        from bve.reporting.charts import save_all_charts
        chart_dir = out_dir / "charts"
        chart_paths = save_all_charts(output, str(chart_dir))
        for k, v in chart_paths.items():
            artifacts[f"chart_{k}"] = v

    print(f"\nOutputs → {out_dir}/")
    for k, v in artifacts.items():
        rel = Path(v).relative_to(Path(args.out)) if Path(v).exists() else Path(v)
        print(f"  {k:<28} {rel}")


if __name__ == "__main__":
    main()
