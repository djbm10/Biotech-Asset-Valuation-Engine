"""
ClinicalTrials.gov v2 REST API client.

Docs: https://clinicaltrials.gov/data-api/api
"""
from __future__ import annotations

import os
import time
import warnings
from dataclasses import dataclass, field
from typing import Any, Optional

import requests

from bve.config.constants import PHASE_DURATIONS_YEARS, PHASE_COSTS_MILLIONS
from bve.entities.trial import (
    ClinicalTrial, TrialArm, TrialPhase, TrialStatus
)

BASE_URL = "https://clinicaltrials.gov/api/v2"

_STATUS_MAP: dict[str, TrialStatus] = {
    "NOT_YET_RECRUITING": TrialStatus.NOT_YET_RECRUITING,
    "RECRUITING": TrialStatus.RECRUITING,
    "ACTIVE_NOT_RECRUITING": TrialStatus.ACTIVE_NOT_RECRUITING,
    "COMPLETED": TrialStatus.COMPLETED,
    "TERMINATED": TrialStatus.TERMINATED,
    "WITHDRAWN": TrialStatus.WITHDRAWN,
}

_PHASE_MAP: dict[str, TrialPhase] = {
    "PHASE1": TrialPhase.PHASE_1,
    "PHASE2": TrialPhase.PHASE_2,
    "PHASE3": TrialPhase.PHASE_3,
    "PHASE4": TrialPhase.PHASE_3,  # treat Phase 4 as Phase 3 for valuation
}


#: One connection pool for the process. ``requests.get`` opens a fresh connection per
#: call -- DNS lookup, TCP handshake, TLS handshake and CA-bundle load each time -- which
#: is invisible for a handful of studies and dominant for a paginated corpus sweep: a
#: 25-record profile spent ~558s, a quarter of its wall clock, on setup it could reuse.
_SESSION = requests.Session()


#: Per-request budget. 30s is comfortable for a handful of studies and brittle for a
#: single broad facet: the PDCD1 ``MONOCLONAL_ANTIBODY`` query is ~2,500 records over 11
#: pages, and under full-pipeline load one of those pages crossing 30s was enough to fail
#: the query, blacklist CT.gov, and silently drop the eight modality queries behind it.
#: Exhaustive benchmark runs raise this; interactive callers keep the shorter budget.
DEFAULT_TIMEOUT = int(os.environ.get("BVE_CTGOV_TIMEOUT", "30"))
DEFAULT_RETRIES = int(os.environ.get("BVE_CTGOV_RETRIES", "3"))


def _get(
    path: str,
    params: dict | None = None,
    timeout: int | None = None,
    retries: int | None = None,
) -> dict:
    timeout = DEFAULT_TIMEOUT if timeout is None else timeout
    retries = DEFAULT_RETRIES if retries is None else retries
    url = f"{BASE_URL}{path}"
    for attempt in range(retries):
        try:
            r = _SESSION.get(url, params=params, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except requests.RequestException:
            if attempt == retries - 1:
                raise
            time.sleep(2 ** attempt)
    return {}  # unreachable but satisfies type checker


def fetch_study(nct_id: str) -> dict[str, Any]:
    """Fetch a single study by NCT ID. Returns raw protocol section dict."""
    data = _get(f"/studies/{nct_id}")
    return data.get("protocolSection", {})


def search_studies(
    condition: Optional[str] = None,
    intervention: Optional[str] = None,
    sponsor: Optional[str] = None,
    status_filter: Optional[list[str]] = None,
    page_size: int = 100,
    max_records: Optional[int] = None,
    timeout: Optional[int] = None,
    retries: Optional[int] = None,
    page_counter: Optional[list[int]] = None,
) -> list[dict[str, Any]]:
    """
    Search ClinicalTrials.gov and return a list of raw protocol sections.

    Parameters
    ----------
    condition:   disease/condition keyword  (query.cond)
    intervention: drug/treatment name       (query.intr)
    sponsor:     sponsor name               (query.spons)
    status_filter: list of statuses to include, e.g. ["RECRUITING", "ACTIVE_NOT_RECRUITING"]
    page_size:   results per page (max 1000) -- a transport setting
    max_records: stop after this many studies; ``None`` sweeps every page. This is a
                 policy bound, deliberately separate from ``page_size``: paging is how
                 the API is read, not how much of the universe the caller wants.
    """
    params: dict[str, Any] = {"pageSize": min(page_size, 1000)}
    if condition:
        params["query.cond"] = condition
    if intervention:
        params["query.intr"] = intervention
    if sponsor:
        params["query.spons"] = sponsor
    if status_filter:
        params["filter.overallStatus"] = ",".join(status_filter)

    studies: list[dict] = []
    page_token: Optional[str] = None

    while True:
        if page_token:
            params["pageToken"] = page_token
        data = _get("/studies", params=params, timeout=timeout, retries=retries)
        if page_counter is not None:
            page_counter.append(1)
        for s in data.get("studies", []):
            proto = s.get("protocolSection", {})
            if proto:
                studies.append(proto)
        page_token = data.get("nextPageToken")
        if not page_token or (max_records is not None and len(studies) >= max_records):
            break

    return studies if max_records is None else studies[:max_records]


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def _parse_phase(protocol: dict) -> Optional[TrialPhase]:
    design = protocol.get("designModule", {})
    phases: list[str] = design.get("phases", [])
    for p in phases:
        if p in _PHASE_MAP:
            return _PHASE_MAP[p]
    return None


def _parse_status(protocol: dict) -> TrialStatus:
    raw = protocol.get("statusModule", {}).get("overallStatus", "")
    return _STATUS_MAP.get(raw, TrialStatus.UNKNOWN)


def _parse_enrollment(protocol: dict) -> Optional[int]:
    enroll = protocol.get("designModule", {}).get("enrollmentInfo", {})
    count = enroll.get("count")
    return int(count) if count else None


def _parse_dates(protocol: dict) -> tuple[Optional[str], Optional[str]]:
    sm = protocol.get("statusModule", {})
    start = sm.get("startDateStruct", {}).get("date")
    primary_completion = sm.get("primaryCompletionDateStruct", {}).get("date")
    return start, primary_completion


def _parse_primary_endpoint(protocol: dict) -> Optional[str]:
    outcomes = protocol.get("outcomesModule", {})
    primary = outcomes.get("primaryOutcomes", [])
    if primary:
        return primary[0].get("measure")
    return None


def _parse_arms(protocol: dict) -> list[TrialArm]:
    arms_raw = protocol.get("armsInterventionsModule", {}).get("armGroups", [])
    arms = []
    for a in arms_raw:
        arms.append(TrialArm(
            label=a.get("label", ""),
            arm_type=a.get("type", "EXPERIMENTAL"),
            intervention=a.get("interventionNames", [None])[0],
        ))
    return arms


def _estimate_duration(start: Optional[str], completion: Optional[str]) -> float:
    """Compute duration in years from ISO date strings. Falls back to phase default."""
    if start and completion:
        try:
            from datetime import date
            # Handle YYYY-MM and YYYY-MM-DD
            start[:10].ljust(10, "-01"[:10 - len(start[:7])])
            completion[:10].ljust(10, "-01"[:10 - len(completion[:7])])
            d0 = date.fromisoformat(start[:7] + "-01")
            d1 = date.fromisoformat(completion[:7] + "-01")
            years = (d1 - d0).days / 365.25
            if 0.25 < years < 15:
                return round(years, 1)
        except (ValueError, TypeError):
            pass
    return None


def parse_trial(
    protocol: dict,
    asset_id: str,
    fallback_success_prob: float = 0.40,
) -> Optional[ClinicalTrial]:
    """
    Convert a raw ClinicalTrials.gov protocol section → ClinicalTrial entity.

    success_probability is set to fallback_success_prob; caller should override
    with the POS model after construction.
    """
    phase = _parse_phase(protocol)
    if phase is None:
        return None

    id_module = protocol.get("identificationModule", {})
    nct_id = id_module.get("nctId")
    title = id_module.get("briefTitle")

    status = _parse_status(protocol)
    enrollment = _parse_enrollment(protocol)
    start_date, completion_date = _parse_dates(protocol)
    primary_endpoint = _parse_primary_endpoint(protocol)
    arms = _parse_arms(protocol)

    duration = _estimate_duration(start_date, completion_date)
    if duration is None:
        duration = PHASE_DURATIONS_YEARS[phase.value]

    cost = PHASE_COSTS_MILLIONS[phase.value]

    return ClinicalTrial(
        asset_id=asset_id,
        phase=phase,
        nct_id=nct_id,
        title=title,
        success_probability=fallback_success_prob,
        primary_endpoint=primary_endpoint,
        duration_years=duration,
        cost_millions=cost,
        start_date=start_date,
        primary_completion_date=completion_date,
        enrollment=enrollment,
        arms=arms,
        status=status,
        data_source="clinicaltrials_gov",
    )


def fetch_trials_for_drug(
    drug_name: str,
    asset_id: str,
    status_filter: Optional[list[str]] = None,
) -> list[ClinicalTrial]:
    """
    Convenience: search by drug name, parse all returned studies into ClinicalTrial objects.

    Parameters
    ----------
    drug_name:  intervention name to search (e.g. "sotorasib")
    asset_id:   asset ID to tag on returned trials
    status_filter: default includes recruiting + active + completed

    Returns
    -------
    List of ClinicalTrial objects (success_probability set to phase default; override with POS model).
    """
    if status_filter is None:
        status_filter = ["RECRUITING", "ACTIVE_NOT_RECRUITING", "COMPLETED"]

    protocols = search_studies(intervention=drug_name, status_filter=status_filter)
    trials = []
    for proto in protocols:
        t = parse_trial(proto, asset_id=asset_id)
        if t is not None:
            trials.append(t)
    return trials


def fetch_trial_by_nct(nct_id: str, asset_id: str) -> Optional[ClinicalTrial]:
    """Fetch a single trial by NCT ID and parse it."""
    proto = fetch_study(nct_id)
    if not proto:
        return None
    return parse_trial(proto, asset_id=asset_id)


# ---------------------------------------------------------------------------
# CT.gov registry validation
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """
    Result of comparing a ClinicalTrial object against the live CT.gov registry.

    Fields
    ------
    nct_id          : The NCT identifier that was looked up.
    registry_found  : True if the registry returned a valid protocol section.
    phase_match     : True/False on match; None if not determinable.
    status_match    : True/False on match; None if not determinable.
    endpoint_match  : True/False on match; None if not determinable.
    mismatches      : Human-readable descriptions of each field mismatch.
    evidence_grade  : Derived evidence quality string:
                        "calibrated"        — all comparable fields match
                        "evidence_informed" — no mismatches but some fields not comparable
                        "unvalidated"       — any field mismatch detected
    """
    nct_id: str
    registry_found: bool
    phase_match: Optional[bool] = None
    status_match: Optional[bool] = None
    endpoint_match: Optional[bool] = None
    mismatches: list[str] = field(default_factory=list)
    evidence_grade: str = "unvalidated"


def validate_against_registry(nct_id: str, trial: ClinicalTrial) -> ValidationResult:
    """
    Validate a ClinicalTrial object against the live ClinicalTrials.gov registry.

    Fetches the live protocol for *nct_id*, then compares:
    - ``trial.phase`` vs registry phase
    - ``trial.status`` vs registry overall status (when ``trial.status`` is set)
    - ``trial.primary_endpoint`` vs registry primary outcome measure (when set)

    Mismatches emit ``UserWarning`` and degrade ``evidence_grade`` to
    ``"unvalidated"``. When all comparable fields match the grade is
    ``"calibrated"``. When no mismatches exist but some fields could not be
    compared the grade is ``"evidence_informed"``.

    Parameters
    ----------
    nct_id : str
        The NCT identifier to look up (e.g. "NCT04083976").
    trial : ClinicalTrial
        The analyst-provided trial object to validate.

    Returns
    -------
    ValidationResult
    """
    result = ValidationResult(nct_id=nct_id, registry_found=False)

    try:
        proto = fetch_study(nct_id.strip().upper())
    except Exception as exc:
        warnings.warn(
            f"CT.gov validation: failed to fetch {nct_id}: {exc}",
            UserWarning,
            stacklevel=2,
        )
        result.evidence_grade = "unvalidated"
        return result

    if not proto:
        warnings.warn(
            f"CT.gov validation: no registry record found for {nct_id}.",
            UserWarning,
            stacklevel=2,
        )
        result.evidence_grade = "unvalidated"
        return result

    result.registry_found = True

    # --- Phase comparison ---
    registry_phase = _parse_phase(proto)
    if registry_phase is not None:
        result.phase_match = registry_phase == trial.phase
        if not result.phase_match:
            msg = (
                f"CT.gov validation [{nct_id}]: phase mismatch — "
                f"registry={registry_phase.value!r}, trial={trial.phase.value!r}."
            )
            warnings.warn(msg, UserWarning, stacklevel=2)
            result.mismatches.append(msg)

    # --- Status comparison ---
    if hasattr(trial, "status") and trial.status is not None:
        registry_status = _parse_status(proto)
        if registry_status != TrialStatus.UNKNOWN:
            result.status_match = registry_status == trial.status
            if not result.status_match:
                msg = (
                    f"CT.gov validation [{nct_id}]: status mismatch — "
                    f"registry={registry_status.value!r}, trial={trial.status.value!r}."
                )
                warnings.warn(msg, UserWarning, stacklevel=2)
                result.mismatches.append(msg)

    # --- Primary endpoint comparison ---
    if trial.primary_endpoint:
        registry_endpoint = _parse_primary_endpoint(proto)
        if registry_endpoint:
            # Fuzzy: check if either string contains the other's key terms (case-insensitive)
            trial_ep_lower = trial.primary_endpoint.lower()
            registry_ep_lower = registry_endpoint.lower()
            # Consider a match if there is >50% word overlap (avoids false negatives from
            # minor phrasing differences; analysts often paraphrase CT.gov language)
            trial_words = set(trial_ep_lower.split())
            registry_words = set(registry_ep_lower.split())
            common = trial_words & registry_words
            overlap = len(common) / max(len(trial_words), len(registry_words), 1)
            result.endpoint_match = overlap > 0.5
            if not result.endpoint_match:
                msg = (
                    f"CT.gov validation [{nct_id}]: primary endpoint mismatch — "
                    f"registry={registry_endpoint!r}, trial={trial.primary_endpoint!r}."
                )
                warnings.warn(msg, UserWarning, stacklevel=2)
                result.mismatches.append(msg)

    # --- Derive evidence grade ---
    if result.mismatches:
        result.evidence_grade = "unvalidated"
    else:
        # All checked fields matched; if at least one field was actually compared → calibrated
        any_compared = any(
            v is not None
            for v in (result.phase_match, result.status_match, result.endpoint_match)
        )
        result.evidence_grade = "calibrated" if any_compared else "evidence_informed"

    return result
